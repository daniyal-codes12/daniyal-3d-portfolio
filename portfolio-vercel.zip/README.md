# Daniyal Channa portfolio (Vercel-ready)
Deploy: drop `index.html` in the repo root (static site, no build step). Back up the old code first: `git checkout -b backup-original` before replacing files.
`dots.bin` (78,000 dots) and `photo.webp` are the source assets already embedded in index.html.
